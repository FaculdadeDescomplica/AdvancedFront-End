export class LoginFormComponent implements OnInit {
  loginForm: FormGroup;

  ngOnInit() {
    // Students will implement form controls and validations
  }
} 